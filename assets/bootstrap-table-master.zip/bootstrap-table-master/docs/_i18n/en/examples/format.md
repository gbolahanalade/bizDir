# Format []({{ site.repo }}/blob/master/docs/_i18n/{{ site.lang }}/examples/format.md)

Use `formatter` column option to format the display of bootstrap table column. _by [@wenzhixin](https://github.com/wenzhixin)_

<iframe width="100%" height="300" data-src="http://jsfiddle.net/wenyi/e3nk137y/21/embedded/html,js,result" allowfullscreen="allowfullscreen" frameborder="0"></iframe>

# Show current row count using Formatter []({{ site.repo }}/blob/master/docs/_i18n/{{ site.lang }}/examples/format.md)

Use `formatter` column option to display the index of the current row. _by [@DominikAngerer](https://github.com/DominikAngerer)_

<iframe width="100%" height="300" data-src="http://jsfiddle.net/DominikAngerer/yx275pyd/2/embedded/" allowfullscreen="allowfullscreen" frameborder="0"></iframe>
